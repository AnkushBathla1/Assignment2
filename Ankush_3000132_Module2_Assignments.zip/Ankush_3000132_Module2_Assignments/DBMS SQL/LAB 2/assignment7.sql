select instr('Mississippi','i',1,3) 
	from dual;