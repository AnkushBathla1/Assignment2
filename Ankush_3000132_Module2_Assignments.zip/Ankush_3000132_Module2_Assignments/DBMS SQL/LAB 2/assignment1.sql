select staff_name, LPAD(staff_sal, 15, '$')
	from staff_master;		