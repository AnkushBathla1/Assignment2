insert into customer
	values (1002, 'John', '#114 Chicago', '#114 Chicago', 'M', 45, 439525);