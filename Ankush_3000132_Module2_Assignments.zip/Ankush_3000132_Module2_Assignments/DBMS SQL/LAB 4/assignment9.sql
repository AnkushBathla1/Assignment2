alter table customer 
	drop constraint custid_prim;
	
insert into customer
	values (1002, 'Becker', '#114 New York', '#114 New york' , 'M', 45, 431525, 15000.50);
	
insert into customer
	values (1003, 'Nanapatekar', '#115 India', '#115 India' , 'M', 45, 431525, 20000.50);
	