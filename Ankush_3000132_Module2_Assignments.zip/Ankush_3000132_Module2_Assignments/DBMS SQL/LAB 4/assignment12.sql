alter table customer
	drop column e_mail;