alter table customer
	add e_mail varchar2(50);