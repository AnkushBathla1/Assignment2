insert into department_master
	values(seq_dept.nextval, 'TRAINING' );
	
insert into department_master
	values(seq_dept.nextval, 'TRAI' );
	
insert into department_master
	values(seq_dept.nextval, 'TRAIN' );