alter table customer
add (gender varchar2(1),age number(3),phoneno number(10));